import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { BookRecommendationComponent } from './components/book-recommendation/book-recommendation.component';
import { AppRoutingModule } from './app-routing.module';  // Import Routing Module

@NgModule({
  declarations: [
    AppComponent, // Declare root component
    BookRecommendationComponent // Declare book recommendation component
  ],
  imports: [
    BrowserModule, // Required for browser apps
    FormsModule, // Enable form handling
    HttpClientModule, // Enable HTTP calls
    AppRoutingModule  // Add routing module
  ],
  providers: [], // No additional providers
  bootstrap: [AppComponent] // Bootstrap with AppComponent
})
export class AppModule { }
