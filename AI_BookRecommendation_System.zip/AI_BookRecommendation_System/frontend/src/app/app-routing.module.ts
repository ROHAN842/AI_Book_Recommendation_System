import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

// Define application routes (currently empty)
const routes: Routes = [];

@NgModule({
  imports: [RouterModule.forRoot(routes)], // Initialize router with routes
  exports: [RouterModule] // Export RouterModule for use in app
})
export class AppRoutingModule { }
