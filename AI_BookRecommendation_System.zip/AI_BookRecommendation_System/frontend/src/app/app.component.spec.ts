import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';

// Test suite for AppComponent
describe('AppComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule // Mock routing for tests
      ],
      declarations: [
        AppComponent // Declare AppComponent for testing
      ],
    }).compileComponents(); // Compile components
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy(); // Verify app creation
  });

  it(`should have as title 'bookfrontend'`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app.title).toEqual('bookfrontend'); // Check title property
  });

  it('should render title', () => {
    const fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges(); // Trigger view rendering
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('.content span').textContent).toContain('bookfrontend app is running!'); // Verify title renders
  });
});
