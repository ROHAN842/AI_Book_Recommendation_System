import { Component } from '@angular/core';

@Component({
  selector: 'app-root', // Root selector
  templateUrl: './app.component.html', // Template file
  styleUrls: ['./app.component.css'] // CSS file
})
export class AppComponent {
  title = 'bookfrontend'; // App title
}
