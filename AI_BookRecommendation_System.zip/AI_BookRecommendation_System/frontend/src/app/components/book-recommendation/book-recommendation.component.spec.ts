import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BookRecommendationComponent } from './book-recommendation.component';

// Test suite for BookRecommendationComponent
describe('BookRecommendationComponent', () => {
  let component: BookRecommendationComponent;
  let fixture: ComponentFixture<BookRecommendationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BookRecommendationComponent ]  // Declare the component
    })
    .compileComponents();  // Compile the component and template
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BookRecommendationComponent); // Create the component instance
    component = fixture.componentInstance;
    fixture.detectChanges(); // Trigger change detection
  });

  it('should create', () => {
    expect(component).toBeTruthy(); // Test if the component is created successfully
  });
});
