import { Component, ChangeDetectorRef, OnInit } from '@angular/core';
import { BookService } from '../../services/book.service';

declare var particlesJS: any; // Declare particles.js for background animation

@Component({
  selector: 'app-book-recommendation',
  templateUrl: './book-recommendation.component.html',
  styleUrls: ['./book-recommendation.component.css']
})
export class BookRecommendationComponent { 
  userInput: string = ''; // User input for author/genre
  recommendations: any[] = []; // Array to hold book recommendations
  loading: boolean = false; // Loading state for UI
  errorMessage: string = '';  // Error message to display
  visibleQuotes: string[] = []; // Quotes currently visible on screen
  private allQuotes: string[] = [ // Array of famous quotes
    "📚 A reader lives a thousand lives before he dies. - George R.R. Martin",
    "✨ Books are a uniquely portable magic. - Stephen King",
    "📖 Reading is essential for those who seek to rise above the ordinary. - Jim Rohn",
    "🌍 The world belongs to those who read. - Rick Holland",
    "💡 Today a reader, tomorrow a leader. - Margaret Fuller",
    "📜 I have always imagined that paradise will be a kind of library. - Jorge Luis Borges",
    "🧠 The more you read, the more things you will know. - Dr. Seuss",
    "🔥 A book is a dream that you hold in your hands. - Neil Gaiman",
    "💭 We read to know we are not alone. - C.S. Lewis",
    "💖 That’s the thing about books. They let you travel without moving your feet. - Jhumpa Lahiri",
    "📚 Books are mirrors: You only see in them what you already have inside you. - Carlos Ruiz Zafón",
    "🔮 A room without books is like a body without a soul. - Marcus Tullius Cicero"
  ];
  private quoteIndex: number = 0; // Track index of quotes
  private quoteInterval: any; // Interval for rotating quotes

  // List of blocked words to filter input
  private blockedWords: string[] = ['sex', 'lust', 'violence', 'drugs', 'gambling','violence','death','weapon','kill','war','politics','explicit','adult','nsfw'];

  constructor(private bookService: BookService, private cd: ChangeDetectorRef) {}

  // Lifecycle hook to initialize component
  ngOnInit(): void {
    this.loadParticles(); // Load background animation
  }

  // Initialize particles.js animation
  loadParticles() {
    particlesJS.load('particles-js', 'assets/particles.json', function () {
      console.log('Particles.js loaded successfully!');
    });
  }

  // Fetch recommendations from the API
  fetchRecommendations() {
    this.errorMessage = ''; // Reset error message
    if (!this.userInput) {
      this.errorMessage = "❌ Please enter an author name or genre."; // Validate empty input
      return;
    }

    // Check if input contains blocked words
    if (this.blockedWords.some(word => this.userInput.toLowerCase().includes(word))) {
      this.errorMessage = "⚠️ Your query contains words that violate our content policy. Please modify your search.";
      return;
    }

    this.loading = true; // Show loading spinner
    this.recommendations = []; // Clear previous recommendations
    this.visibleQuotes = this.allQuotes.slice(0, 2); // Show first 2 quotes initially

    // Start rotating quotes every 8 seconds
    this.quoteInterval = setInterval(() => {
      this.quoteIndex = (this.quoteIndex + 2) % this.allQuotes.length;
      this.visibleQuotes = [
        this.allQuotes[this.quoteIndex],
        this.allQuotes[(this.quoteIndex + 1) % this.allQuotes.length]
      ];
      this.cd.detectChanges(); // Manually trigger change detection
    }, 8000);

    // Call backend API for recommendations
    this.bookService.getRecommendations(this.userInput).subscribe(
      (data: { recommendations?: any[] }) => {
        this.loading = false;
        clearInterval(this.quoteInterval); // Stop rotating quotes

        if (!data.recommendations || data.recommendations.length === 0) {
          this.errorMessage = "⚠️ No recommendations found. Try another search!";
          return;
        }

        // Map API response to UI-friendly format
        this.recommendations = data.recommendations.map(book => ({
          title: book.title,
          author: book.author,
          description: book.description,
          imageUrl: book.image_url
        }));
      },
      (error: any) => {
        this.loading = false;
        clearInterval(this.quoteInterval); // Stop rotating quotes

        if (error.status === 400 && error.error?.message?.includes("safety system")) {
          this.errorMessage = "🚨 OpenAI policy violation detected. Please modify your query.";
        } else if (error.status === 500) {
          // Handle server error
          this.errorMessage = "🚨 OpenAI policy violation detected as part of their safety system. Kindly modify the query !!";
        } else {
          this.errorMessage = "❌ An unexpected error occurred. Please try again.";
        }
      }
    );
  }
}
