import { TestBed } from '@angular/core/testing';

import { BookService } from './book.service';

// Test suite for BookService
describe('BookService', () => {
  let service: BookService;

  beforeEach(() => {
    TestBed.configureTestingModule({}); // Configure testing module
    service = TestBed.inject(BookService); // Inject BookService instance
  });

  it('should be created', () => {
    expect(service).toBeTruthy(); // Verify service is created
  });
});
