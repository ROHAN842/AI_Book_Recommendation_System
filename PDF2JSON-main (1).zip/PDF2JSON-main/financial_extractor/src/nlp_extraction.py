import re

def extract_financial_metrics(text):
    """Extracts financial figures like revenue, expenses, and net income using regex."""
    financial_data = {}

    revenue_match = re.search(r"Revenue\s*:\s*(\d+[\.,]?\d*)", text)
    expense_match = re.search(r"Total Expenses\s*:\s*(\d+[\.,]?\d*)", text)
    net_income_match = re.search(r"Net Income\s*:\s*(\d+[\.,]?\d*)", text)

    if revenue_match:
        financial_data["total_revenue"] = float(revenue_match.group(1).replace(',', ''))
    if expense_match:
        financial_data["total_expenses"] = float(expense_match.group(1).replace(',', ''))
    if net_income_match:
        financial_data["net_income"] = float(net_income_match.group(1).replace(',', ''))

    return financial_data