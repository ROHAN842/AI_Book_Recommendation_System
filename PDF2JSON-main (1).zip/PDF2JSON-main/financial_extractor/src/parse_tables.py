import pdf2json
import camelot

def extract_tables(pdf_path):
    """Extracts tables from PDF using pdf2json and Camelot as a fallback."""
    try:
        pdf = pdf2json.PDF2JSON()
        pdf.parse(pdf_path)
        extracted_data = pdf.get_json()
        
        tables = []
        for page in extracted_data["pages"]:
            for obj in page.get("texts", []):
                if "Table" in obj["text"]:
                    tables.append(obj["text"])

        if not tables:  # If pdf2json fails, try Camelot
            camelot_tables = camelot.read_pdf(pdf_path, pages="all", flavor="stream")
            tables = [table.df.to_dict(orient="records") for table in camelot_tables]

        return tables
    except Exception as e:
        print(f"Error extracting tables: {e}")
        return []