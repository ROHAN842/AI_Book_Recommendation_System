import json
from src.extract import extract_data

pdf_path = "../data/pdfs/sample.pdf"
output = extract_data(pdf_path)

# Save output as JSON
with open("../data/json_samples/output.json", "w") as json_file:
    json.dump(output, json_file, indent=4)

print("Extraction completed! JSON output saved.")