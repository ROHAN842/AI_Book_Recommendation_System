import pdf2json
import json

def extract_text(pdf_path):
    """Extracts structured text from a PDF using pdf2json."""
    pdf = pdf2json.PDF2JSON()
    pdf.parse(pdf_path)
    data = pdf.get_json()
    return data

def extract_data(pdf_path):
    """Converts extracted PDF data into structured JSON format."""
    extracted_text = extract_text(pdf_path)
    
    structured_data = {
        "standalone": {},
        "consolidated": {}
    }
    
    # Parse extracted text for financial data (customize this logic)
    for page in extracted_text['pages']:
        for text in page['texts']:
            if "Balance Sheet" in text['text']:
                structured_data["standalone"]["balance_sheet"] = text['text']
            if "Income Statement" in text['text']:
                structured_data["standalone"]["income_statement"] = text['text']
    
    return structured_data

if __name__ == "__main__":
    sample_pdf = "../data/pdfs/sample.pdf"
    output = extract_data(sample_pdf)
    print(json.dumps(output, indent=4))