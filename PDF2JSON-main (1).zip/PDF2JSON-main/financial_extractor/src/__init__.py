# src/__init__.py
print("Initializing the src package...")
