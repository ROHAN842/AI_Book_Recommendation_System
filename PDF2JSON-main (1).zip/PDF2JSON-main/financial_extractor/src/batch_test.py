import json
import os
from src.extract import extract_data

def batch_test(input_dir, output_dir):
    """Processes multiple PDFs and extracts structured JSON data."""
    pdf_files = [f for f in os.listdir(input_dir) if f.endswith('.pdf')]

    for pdf in pdf_files:
        pdf_path = os.path.join(input_dir, pdf)
        output = extract_data(pdf_path)
        
        output_file = os.path.join(output_dir, f"{pdf.split('.')[0]}_output.json")
        with open(output_file, "w") as json_file:
            json.dump(output, json_file, indent=4)
        
        print(f"Processed: {pdf} → Output saved at: {output_file}")

if __name__ == "__main__":
    input_dir = "../data/pdfs/"
    output_dir = "../data/json_samples/"
    batch_test(input_dir, output_dir)