import streamlit as st
from src.extract import extract_data
import json

st.title("📊 Financial Statement Extractor")

uploaded_file = st.file_uploader("📂 Upload a PDF", type="pdf")

if uploaded_file:
    with open("temp.pdf", "wb") as f:
        f.write(uploaded_file.read())

    st.text("🔄 Extracting data...")
    output = extract_data("temp.pdf")

    st.subheader("📜 Extracted JSON Output")
    st.json(output)

    json_output = json.dumps(output, indent=4)
    st.download_button("⬇️ Download JSON", json_output, file_name="output.json", mime="application/json")