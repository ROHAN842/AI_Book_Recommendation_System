# **Financial Statement Extractor**  
A Python-based solution to extract **Standalone and Consolidated Financial Statements** from PDF documents and convert them into structured **JSON format** using freely available tools.

---

## **Project Overview**  
This project extracts financial data from PDFs and structures it into JSON format. It supports:  
✅ **Standalone financial statements**  
✅ **Consolidated financial statements**  
✅ **Tabular data extraction**  

---

## **Features**  
- 📝 **Extracts text and tables from PDFs**  
- 📊 **Converts financial statements into structured JSON**  
- 🔍 **Handles both standalone and consolidated financial statements**  
- 📌 **Uses freely available Python libraries**  
- 🚀 **Batch processing for multiple PDFs**  

---

## **Installation**  

### **1. Clone the Repository**  
```sh
git clone https://github.com/yourusername/financial_extractor.git
cd financial_extractor
```

### **2. Create a Virtual Environment**  
```sh
python -m venv env
source env/bin/activate  # macOS/Linux
env\Scripts\activate     # Windows
```

### **3. Install Dependencies**  
```sh
pip install -r requirements.txt
```

---

## **Usage**  

### **Extract Financial Data from a Single PDF**  
```sh
python src/inference.py
```
This processes `sample.pdf` in `data/pdfs/` and saves the output in `data/json_samples/output.json`.

### **Batch Processing (Multiple PDFs)**  
```sh
python src/batch_test.py
```
Processes all PDFs in `data/pdfs/` and saves the results in `data/json_samples/`.

---

## **Directory Structure**  
```
financial_extractor/
│
├── data/
│   ├── pdfs/               # Input PDFs
│   └── json_samples/       # Output JSON files
│
├── src/
│   ├── extract.py          # Extracts text from PDFs
│   ├── parse_tables.py     # Extracts tabular data
│   ├── nlp_extraction.py   # Extracts financial entities
│   ├── inference.py        # Runs the extraction
│   ├── batch_test.py       # Processes multiple PDFs
│
├── requirements.txt        # Required Python libraries
└── README.md               # Documentation
```

---

## **JSON Output Example**  
```json
{
    "standalone": {
        "income_statement": {
            "revenue": 5000000,
            "expenses": {
                "cost_of_goods_sold": 2000000,
                "operating_expenses": 1000000
            },
            "net_income": 2000000
        }
    },
    "consolidated": {
        "balance_sheet": {
            "assets": {
                "current_assets": {
                    "cash_and_cash_equivalents": 300000,
                    "inventory": 200000
                }
            }
        }
    }
}
```

---

## **Challenges Faced**  
- 📄 **Variations in PDF layouts**  
- 🔍 **Different terminologies across financial statements**  
- 📊 **Tables with inconsistent formatting**  
- ⚙️ **Handling missing or incomplete data in some PDFs**  

---

## **Future Enhancements**  
- 🏗 **Improve NLP-based extraction for better accuracy**  
- 📈 **Enhance table parsing with AI models like LayoutLM**  
- 🖥 **Build a Streamlit UI for better user interaction**  
- 📂 **Support for Excel output format**  

---

## **Contributing**  
Want to contribute? Please open a pull request or issue!  

---

## **License**  
This project is open-source and available under the MIT License.  

---

## **Contact**  
For any queries, reach out at:
🔗 GitHub: [AbhishekKantharia](https://github.com/AbhishekKantharia)  

---

### **How to Use This**  
- Save the file as **`README.md`** in the root of your project.  
- It will display nicely on GitHub and in markdown viewers.  
- Replace `"yourusername"` and `"your-email@example.com"` with your actual details.  

This file provides a **clear, structured, and professional README** for your project. Let me know if you need any changes! 🚀
